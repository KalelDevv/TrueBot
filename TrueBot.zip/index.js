require('dotenv').config();
const { Client, GatewayIntentBits, Partials, PermissionsBitField } = require('discord.js');

// ==== CONFIG ====
const DISCORD_TOKEN = process.env.DISCORD_TOKEN;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.0-flash';

// ID do servidor (guild) onde o bot deve funcionar. Deixe vazio pra permitir qualquer servidor.
const GUILD_ID = process.env.GUILD_ID || '';

// Cargos que têm permissão de fazer o bot responder.
// Preenchemos 5 variáveis (ALLOWED_ROLE_ID_1 a 5) pra você ir adicionando cargos no futuro
// direto pelas variáveis de ambiente do Railway, sem precisar mexer no código.
const ALLOWED_ROLE_IDS = [
  process.env.ALLOWED_ROLE_ID_1,
  process.env.ALLOWED_ROLE_ID_2,
  process.env.ALLOWED_ROLE_ID_3,
  process.env.ALLOWED_ROLE_ID_4,
  process.env.ALLOWED_ROLE_ID_5,
].filter(Boolean);

// Não precisamos de lista de canal proibido: o bot só responde onde ele
// TEM permissão de ver e enviar mensagens. Se você tirar a permissão dele
// num canal, ele automaticamente para de responder lá (ver checagens abaixo).

// Personalidade do bot — ajuste como quiser
const SYSTEM_PROMPT = `Você é um bot do Discord que conversa de forma natural, curta e humana, como se fosse uma pessoa real no servidor.
Regras:
- Responda em português do Brasil, de forma casual e direta.
- Não se apresente como IA/bot a menos que perguntem diretamente.
- Seja objetivo: respostas curtas (1 a 4 frases), a não ser que o assunto exija mais.
- Se receber o contexto de uma mensagem que a pessoa está respondendo, leve esse contexto em conta pra dar uma resposta coerente com o que estava sendo discutido.
- Nunca invente informações sobre o servidor ou sobre pessoas que você não tem.`;

// ==== CLIENT ====
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Message, Partials.Channel],
});

client.once('ready', () => {
  console.log(`Bot online como ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
  try {
    // Ignora mensagens de outros bots (evita loop)
    if (message.author.bot) return;

    // Trava extra: só responde dentro do servidor configurado (se GUILD_ID estiver setado)
    if (GUILD_ID && message.guild?.id !== GUILD_ID) return;

    // Só responde se o bot foi mencionado diretamente
    const foiMencionado = message.mentions.has(client.user);
    if (!foiMencionado) return;

    // Checa se quem mandou a mensagem tem um dos cargos permitidos
    if (ALLOWED_ROLE_IDS.length > 0) {
      const membro = message.member;
      const temCargoPermitido = membro?.roles?.cache?.some((cargo) =>
        ALLOWED_ROLE_IDS.includes(cargo.id)
      );
      if (!temCargoPermitido) return;
    }

    // Checa se o bot tem permissão de ver e enviar mensagem nesse canal.
    // Se você tirou a permissão dele no canal, ele simplesmente não faz nada aqui.
    const permissoes = message.channel.permissionsFor(client.user);
    const podeResponder =
      permissoes?.has(PermissionsBitField.Flags.ViewChannel) &&
      permissoes?.has(PermissionsBitField.Flags.SendMessages);
    if (!podeResponder) return;

    // Remove a menção do texto pra não poluir o prompt (ex: "@Bot oi" -> "oi")
    const conteudoLimpo = message.content
      .replace(new RegExp(`<@!?${client.user.id}>`, 'g'), '')
      .trim();

    // Se a mensagem é uma resposta (reply) a outra mensagem, busca o conteúdo original
    let contextoRespondido = null;
    if (message.reference?.messageId) {
      try {
        const mensagemOriginal = await message.channel.messages.fetch(
          message.reference.messageId
        );
        if (mensagemOriginal && mensagemOriginal.id !== message.id) {
          contextoRespondido = {
            autor: mensagemOriginal.author.username,
            conteudo: mensagemOriginal.content,
          };
        }
      } catch (e) {
        console.warn('Não consegui buscar a mensagem respondida:', e.message);
      }
    }

    await message.channel.sendTyping();

    const respostaIA = await gerarResposta({
      autor: message.author.username,
      mensagem: conteudoLimpo || '(mencionou o bot sem escrever nada)',
      contextoRespondido,
    });

    await message.reply({
      content: respostaIA,
      allowedMentions: { repliedUser: false },
    });
  } catch (erro) {
    console.error('Erro ao processar mensagem:', erro);
  }
});

// ==== CHAMADA PRA IA (Gemini — grátis) ====
async function gerarResposta({ autor, mensagem, contextoRespondido }) {
  let textoUsuario = `${autor} disse: "${mensagem}"`;
  if (contextoRespondido) {
    textoUsuario =
      `Contexto: a mensagem original que está sendo comentada, de "${contextoRespondido.autor}", foi: "${contextoRespondido.conteudo}"\n\n` +
      textoUsuario;
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`;

  const resposta = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
      contents: [{ role: 'user', parts: [{ text: textoUsuario }] }],
      generationConfig: {
        maxOutputTokens: 400,
        temperature: 0.8,
      },
    }),
  });

  if (!resposta.ok) {
    const erroTexto = await resposta.text();
    console.error('Erro da API Gemini:', erroTexto);
    return 'Deu ruim aqui pra pensar numa resposta, tenta de novo mais tarde.';
  }

  const dados = await resposta.json();
  const texto = dados.candidates?.[0]?.content?.parts?.[0]?.text;
  return texto?.trim() || 'Não consegui pensar em nada agora 😅';
}

client.login(DISCORD_TOKEN);
